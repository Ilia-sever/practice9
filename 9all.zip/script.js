function f7 () 
{
	let w=window.outerWidth;
	let h=window.outerHeight;
	let w2,h2;
	let b=1;
	window.onresize = function() 
	{
		if ((b==1)&&(window.outerWidth!=w)&&(window.outerHeight!=h)) 
		{
			b=0;
			setTimeout( function() 
			{
				w2=window.outerWidth;
				h2=window.outerHeight;
				let que = confirm('изменились параметры окна – хотите оставить старые или новые применить?');
				if (que==true)
				{
					window.resizeTo(w,h);
					b=1;
				}
				else
				{
					w=w2;h=h2;
					b=1;
				}
			},5000)
		}
	}
}