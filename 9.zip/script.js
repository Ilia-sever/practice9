function f7 () 
{
	let w=window.outerWidth;
	let h=window.outerHeight;
	let w2,h2;
	let b=1;
	window.onresize = function() 
	{
		if (b==1)
		{
			b=0;
			setTimeout( function() 
			{
				if ((window.outerWidth!=w)||(window.outerHeight!=h))
				{
					
					let que = confirm('Изменились параметры окна – применить новые?');
					if (que==false)
					{
						window.resizeTo(w,h);
						b=1;
						
					}
					else
					{
						w=window.outerWidth;h=window.outerHeight;
						b=1;
						
					}
				}
				else b=1;
			},5000)
		}
	}
}
